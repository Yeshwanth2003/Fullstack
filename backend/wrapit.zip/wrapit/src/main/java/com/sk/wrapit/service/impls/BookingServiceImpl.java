package com.sk.wrapit.service.impls;

import org.springframework.stereotype.Service;

import com.sk.wrapit.service.BookingService;

@Service
public class BookingServiceImpl implements BookingService {

}
