package com.sk.wrapit.service;

public interface BookingService {

}
