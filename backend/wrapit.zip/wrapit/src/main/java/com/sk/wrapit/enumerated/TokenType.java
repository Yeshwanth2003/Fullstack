package com.sk.wrapit.enumerated;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum TokenType {
    BEARER,
    BEARER_RESET
}
