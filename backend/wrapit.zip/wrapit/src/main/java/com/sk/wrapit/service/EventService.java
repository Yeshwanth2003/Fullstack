package com.sk.wrapit.service;

public interface EventService {

}
